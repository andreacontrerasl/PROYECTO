import random
from sympy import Symbol, diff, sin, cos, tan
import math
from fractions import Fraction

def pick_option(options_list):
    random_option = random.choice(options_list)
    return random_option

def preguntas_matematicas_main(vidas, gano):
    options_list = ["Calcula la derivada de la función evaluada en pi  f(x)=sen(x)/2", "Calcula la derivada de la función en pi/2  f(x)=(cos(x))/2 - tan(x))/5", "Calcula la derivada de la función en pi/3 f(x)=(sen(x))/5 -tan(x))"]
    problem = pick_option(options_list)
    if problem == options_list[0]:
        #nombrar a pi con la libreria math
        pi = math.pi
        #nombrar a la incognita
        x = Symbol('x')
        #calcular la derivada con sympy
        dx = diff(sin(x)/2, x)
        #reemplazar la x por pi y calcular
        dx_evaluada = dx.replace(x, pi)
        #redondear el resultado
        dx_evaluada = round(dx_evaluada, 1)
        #cambiar el resultado de decimal a fraccion
        dx_evaluada = str(dx_evaluada)
        dx_evaluada = Fraction(dx_evaluada)
        answer = str(dx_evaluada)
        
    elif problem == options_list[1]:
        pi = math.pi
        x = Symbol('x')
        dx = diff(cos(x)/2 - tan(x)/5, x)
        dx_evaluada = dx.replace(x, pi)
        dx_evaluada = round(dx_evaluada, 1)
        dx_evaluada = str(dx_evaluada)
        dx_evaluada = Fraction(dx_evaluada)
        answer = str(dx_evaluada)
    else:
        pi = math.pi
        pi = pi/3
        x = Symbol('x')
        dx = diff(sin(x)/5 - tan(x), x)
        dx_evaluada = dx.replace(x, pi)
        dx_evaluada = round(dx_evaluada, 1)
        dx_evaluada = str(dx_evaluada)
        dx_evaluada = Fraction(dx_evaluada)
        answer = str(dx_evaluada)
        
    print('''
-----HORA DE DERIVAR-----
Debes derivar la siguente función, en este juego no tienes pistas ups
Buena Suerte!''')
    while True:
        print()
        print(problem)
        print()
        respuesta = input('Ingrese su respuesta en fracciones (separandolo con /) y sin espacios: ')
        #si tiene la respuesta correcta gana y se devuelve al cuarto
        if respuesta == answer:
            print('\nFelicidades ganaste una vida extra')
            gano = True
            break
        #si tiene la respuesta incorrecta se restan vidas
        else:
            print('\nRespuesta incorrecta, vuelve a intentarlo')
            vidas -= 1/4
            if vidas <= 0:
                print('\nSe te acabaron las vidas')
                gano = False
                break
    return vidas, gano

