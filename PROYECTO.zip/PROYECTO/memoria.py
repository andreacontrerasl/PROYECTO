import random

def crear_tablero():
    #Tablero con todos lo emojis volteados
    tablero = [
        [" X "," X "," X "," X "],
        [" X "," X "," X "," X "],
        [" X "," X "," X "," X "],
        [" X "," X "," X "," X "]]
    for i in tablero:
        for j in i:
            print(j," ",end="")
        print()
    return tablero

def mostrar(a, b, tablero, matriz):
    tablero[b-1][a-1] = matriz[a-1][b-1]
    for i in tablero:
        print()
        for j in i:
            print(j," ",end="")
        print()
    return tablero[b-1][a-1]


def limpiar(a1, b1, a2, b2, tablero):
    tablero[b1-1][a1-1] = " X "
    tablero[b2-1][a2-1] = " X "
    for i in tablero:
        for j in i:
            print(j," ",end="")
        print()

def validar(a, b, a2, b2, tablero):
    if a<1 or a>4 or b<1 or b>4 or tablero[b-1][a-1] != " X ":
        print('Posición inválida')
        return False
    elif a == a2 and b == b2:
        print('Esa posicion ya se uso')
        return False
    else:
        return True

def check_moves(tablero):
    guiones = 0
    for i in tablero:
        for j in i:
            if j == " X ":
                guiones += 1
    return guiones


def memoria_emojis_main(vidas, gano):
    matriz = [
    ['😀', '🙄', '🤮', '🥰'], 
    ['🤮', '😨', '🤓', '😷'], 
    ['😨', '🤓', '🥰', '😷'], 
    ['🤑', '🤑', '🙄', '😀']]
    random.shuffle(matriz)
    guiones = 0
    print('''
----MEMORIA----
Debes indicar las coordenadas de la X que desees voltear y acertar las parejas de emojis para ganar
Buena Suerte!''')
    print()
    tablero = crear_tablero()
    print()
    #pista1 = mostrar(1, 3, tablero, matriz)
    #print()
    #pista2 = mostrar(2, 4, tablero, matriz)
    #print()
    #pista3 = mostrar(3, 2, tablero, matriz)
    
    while True:
        valido1 = False
        valido2 = False
        while valido1 == False:
            print()
            print('Los emojis que se muestran tambien debes ingresar sus coordenadas, la ventaja es que ya sabes donde están y lo puedes usar cuando encuentres a su pareja\n')
            print('Recuerda que las filas van - y las columnas |\n')
            a1 = input('Ingrese el número de la columna para el primer emoji: ')
            while not (a1.isnumeric()) or int(a1) not in range(1, 5):
                a1 = input('Ingrese el número de la columna para el primer emoji, debe de ser un número del 1-4: ')
            b1 = input('Ingrese el número de la fila para el primer emoji: ')
            while not (b1.isnumeric()) or int(b1) not in range(1, 5):
                b1 = input('Ingrese el número de la fila para el primer emoji, debe de ser un número del 1-4: ')
            a1 = int(a1)
            b1 = int(b1)
            valido1 = validar(a1, b1, -1, -1, tablero)
        print(f'\nEl emoji de esa posicion es: {matriz[a1-1][b1-1]}\n')
        tabla1 = mostrar(a1,b1,tablero,matriz)
        while valido2 == False:
            a2 = input('Ingrese el número de la columna para el segundo emoji: ')
            while not (a2.isnumeric()) or int(a2) not in range(1, 5):
                a2 = input('Ingrese el número de la columna para el segundo emoji, debe de ser un número del 1-4: ')
            b2 = input('Ingrese el número de la fila para el segundo emoji: ')
            while not (b2.isnumeric()) or int(b2) not in range(1, 5):
                b2 = input('Ingrese el número de la fila para el segundo emoji, debe de ser un número del 1-4: ')
            a2 = int(a2)
            b2 = int(b2)
            valido2 = validar(a2, b2, a1, b1, tablero)
        print(f'\nEl emoji de esa posicion es: {matriz[a2-1][b2-1]}\n')
        tabla2 = mostrar(a2,b2,tablero,matriz)
        if tabla1 == tabla2:
            print('\nMuy bien, acertaste la pareja de emojis')
        else:
            print('\nMmmm, no acertaste, sigue intentando pero recuerdate de las posiciones y los emojis que ya elegiste')
            limpiar(a1, b1, a2, b2, tablero)
            vidas -= 1/4
            if vidas <= 0:
                print('Te quedaste sin vidas')
                gano = False
                break

        if check_moves(tablero) == 0:
            print('\nFelicidades, acertaste todas las parejas de emojis')
            gano = True
            break


    return vidas, gano