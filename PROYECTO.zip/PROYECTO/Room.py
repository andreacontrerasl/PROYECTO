class Room:
    def __init__(self, room_name, lista_objetos):
        self.room_name = room_name
        self.lista_objetos = lista_objetos
        