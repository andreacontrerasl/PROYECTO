#Juego elegir un numero entre
import random

def pista(numero, adivinar_num):
    if adivinar_num < numero:
        print('Estar por debajo')
    elif adivinar_num > numero:
        print('Estas por arriba')

def pick_num_main(vidas, gano):
    numero = random.randrange(1,16)
    print('\n---ESTAS LISTO?---\nDebes adivinar el número')
    while True:
        try:
            adivinar_num = int(input('\nIngresa un número del 1 al 15: '))
            while adivinar_num not in range(1, 16):
                adivinar_num = int(input('Ingresa un número del 1 al 15: '))
        except:
            print('Debe ingresar un número') 

        if adivinar_num < numero:
            print('Estar por debajo del número a adivinar') 
        elif adivinar_num > numero:
            print('Estas por arriba del numero a adivinar')
      
        if adivinar_num == numero:
            print('Felicidades adivinaste el número!')
            gano = True
            break
        else:
            print('Numero incorrecto')
            vidas -= 1//9
            if vidas <= 0:
                print('Se te acabaron las vidas')
                gano = False
                break

    return vidas, gano


