#archivo para las funciones de txt

import pickle
import os

#para buscar en el archivo txt de usuarios
def recibir_txt(nombre_txt,datos): 
    
    lectura_binaria= open(nombre_txt,'rb')
    
    if os.stat(nombre_txt).st_size != 0:
        datos=pickle.load(lectura_binaria)

    lectura_binaria.close()

    return datos

#para agregar al archivo txt de usuarios
def cargar_txt(nombre_txt, datos):  

    escritura_binaria=open(nombre_txt, 'wb')

    datos=pickle.dump(datos, escritura_binaria)
    
    escritura_binaria.close()

