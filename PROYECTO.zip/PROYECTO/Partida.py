from Jugador import *

class Partida(Jugador):
    def __init__(self, username, password, age, avatar, time_x_partida, win):
        super().__init__(username, password, age, avatar)
        self.time_x_partida = time_x_partida
        self.win = win

    def mostrar(self):
        print(f'''
        Username: {self.username}
        Avatar: {self.avatar}
        Tiempo de partida: {self.time_x_partida} segundos
        Gano: {self.win}
        ''')