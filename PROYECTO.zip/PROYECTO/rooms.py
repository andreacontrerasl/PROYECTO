import requests
import sys
import time
from llamar_text import *
from Partida import *
from Objeto import *
from Room import *
import random
from ahorcado import *
from criptograma import *
from adivinanzas import *
from quizziz import *
from pick_num import *
from palabra_mezclada import *
from encuentra_logica import *
from logica_booleana import *
from preg_mate import *
from memoria import *
from preguntas_python import *
from criptograma import *
from completa_refran import *
from sopa_letras import *

#cada cuarto tiene su funcion 
def room_1(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar):
    #nombre del cuarto
    room_1 = room_list[1].room_name
    #nombre de los objetos, juegos etc
    obj_1 = (obje[3]).title()
    game_1 = (games[3]).title()
    award_1 = awards[3]
    obj_2 = (obje[4]).title()
    game_2 = (games[4]).title()
    award_2 = awards[4]
    requirement_1 = requir[4]
    obj_3 = (obje[5]).title()
    game_3 = (games[5]).title()
    award_3 = awards[5]
    requirement_2 = requir[5]
    # si la persona gana o no el juego, retorna un booleano
    gano = False

    print(f'''
                        --{room_1}-- 
     ----------------------------------------------------
    |                                                    |
    |   --------                                         |    
    |  | Mueble |                                        |   
    |  |sentarse|        ---------------                 |
    |   --------        | Mueble libros |                |         
    |                    ---------------      --------   |                     
    |                                        | Mueble |  |       
    |                                        | gabetas|  |      
    |                                         --------   |     
    |                                                    |
     ----------------------------------------------------
    ''')
    while vidas != 0:
        #se empieza a jugar dentro de los cuartos, primero se ve el menu
        print(f'\nTe encuentras en {room_1}')
        menu = input('Para ver el menu presione [1]: ')
        while not (menu.isnumeric()) or int(menu) != 1:
            menu = input('Para ver el menu de lo que puedes hacer presiona [1]: ')

        menu_op = input('''
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')

        while not (menu_op.isnumeric()) or int(menu_op) not in range(1,7):
            menu_op = input('''
            Ingrese el numero de la accion que desea realizar
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')
        #Para moverse entre cuartos
        if menu_op == '1':
            #se muestra en que cuarto esta y cuales son los cuartos a los que se puede mover, se mueve indicanto el punto cardinal
            mover = (input(f'''Actualmente te encuentras en la {room_1}, te puedes mover a:
        [S]. {room_list[3].room_name} al sur de la {room_1}
        [NE]. {room_list[2].room_name} al noreste de la {room_1}
        [V]. Volver al cuarto
        --> ''')).lower()
            while not (mover == 's' or mover == 'ne' or mover == 'v'):
                mover = (input(f'''Indique la direccion (con su inicial) del cuarto al que se quiere mover:
        [S]. {room_list[3].room_name}
        [NE]. {room_list[2].room_name}
        [V]. Volver al cuarto
        --> ''')).lower()
            #dependiendo del cuarto al que se quiera mover se llama a la funcion correspondiente
            if mover == 's':
                room_3(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)

            elif mover == 'ne':
                room_2(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)

        elif menu_op == '2':
            #se muestras los objetos que hay en el cuarto y su posicion 
            touch_object = input(f'''Los objetos que hay en este cuarto son:
        1. {obj_1} ubicado en el centro de la {room_1}
        2. {obj_2} ubicado a la izquierda de la {room_1}
        3. {obj_3} ubicado a la derecha de la {room_1}
        4. Volver a la {room_1}
        --> ''')

            while not(touch_object.isnumeric()) or int(touch_object) not in range(1,5):
                touch_object = input(f'''
        Indique el numero del objeto que desea tocar:
        1. {obj_1} ubicado en el centro de la {room_1}
        2. {obj_2} ubicado a la izquierda de la {room_1}
        3. {obj_3} ubicado a la derecha de la {room_1}
        4. Volver a la {room_1}
        --> ''')

        #dependiendo del objeto que decida tocar se le abrira el juego
            if touch_object == '1':
                #indica el juego que hay en el objeto, sus requerimientos (puede no tener ningun tipo de requerimiento) y vidas que pierde
                print(f'Es hora de jugar el {game_1} para que puedas ganar un {award_1}\nOjo, pierdes un cuarto vida por cada letra incorrecta\nBuena Suerte!')
                vidas, pistas, gano = ahorcado_main(vidas, pistas, gano)
                if gano:
                    #si gana el juego se le agrega el premio a la lista de premios
                    recompensas_list.append(award_1)
                else:
                    if vidas <= 0:
                        #si perdio porque se quedo sin vidas, se guarda la info y se termina el juego
                        win = False
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(username, password, age, avatar, time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        sys.exit()
        

            elif touch_object == '2':
                print(f'Es hora de jugar {game_2} para que puedas ganar una {award_2} \nPara poder jugar debes de tener un {requirement_1} y debes saber derivar \nOjo, pierdes un cuarto de vida por respuesta incorrecra \nBuena Suerte!')
                if requirement_1 in recompensas_list:
                    vidas, gano = preguntas_matematicas_main(vidas, gano)
                    if gano:
                        vidas += 1
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print(f'No tienes {requirement_1} en tu lista de recompensas para poder jugar {game_2}\nPara poder ganarlo debes jugar {games[7]} que está en el cuarto {room_list[2].room_name}, en {obje[7]}')

            elif touch_object == '3':
                print(f'Es hora de descifrar el {game_3}\n{award_3}\nPara poder jugar debes tener la {requirement_2}\nPierdes una vida por partida perdida')
                if requirement_2 in recompensas_list:
                    vidas, gano = criptograma_main(vidas, gano)
                    if gano:
                        recompensas_list.append('Mensaje')
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print(f'No tienes {requirement_2} en tu lista de recompensas para poder jugar {game_3}\nPara poder ganarlo debes jugar {games[2]} que está en el cuarto {room_list[0].room_name}, en {obje[2]}')

        elif menu_op == '3':
            print(f'Las recompensas que tienes hasta ahora son:\n{recompensas_list}\n')

        elif menu_op == '4':
            print(f'Te quedan {pistas} pistas')

        elif menu_op == '5':
            print(f'Te quedan {vidas} vidas')

        else:
            break
    return vidas, pistas, partidas

def room_2(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar):
    room_2 = room_list[2].room_name
    #nombre de los objetos
    obj_1 = (obje[6]).title()
    game_1 = (games[6]).title()
    award_1 = awards[6]
    requirement_1 = requir[6]
    obj_2 = (obje[7]).title()
    game_2 = (games[7]).title()
    award_2 = awards[7]
    requirement_2 = requir[7]
    obj_3 = (obje[8]).title()
    game_3 = (games[8]).title()
    award_3 = awards[8]
    requirement_3 = requir[8]
    gano = False
    print(f'''
                     --{room_2}-- 
     ----------------------------------------------------
    |                                                    |
    |   ---------                                        |    
    |  | Banco 1 |                                       |   
    |   ---------       ---------------                  |
    |                  |     SAMÁN     |                 |         
    |                   ---------------                  |                     
    |                                        ---------   |       
    |                                       | Banco 2 |  |      
    |                                        ---------   |     
    |                                                    |
     ----------------------------------------------------
    ''')

    while True:
        print(f'Te encuentras en {room_2}')
        menu = input('Para ver el menu presione [1]: ')
        while not (menu.isnumeric()) or int(menu) != 1:
            menu = input('Para ver el menu de lo que puedes hacer presiona [1]: ')

        menu_op = input('''
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')

        while not (menu_op.isnumeric()) or int(menu_op) not in range(1,7):
            menu_op = input('''
            Ingrese el numero de la accion que desea realizar
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')
        if menu_op == '1':
            mover = (input(f'''Actualmente te encuentras en la {room_2}, solo te puedes mover a la {room_list[1].room_name}
        Si deseas moverte a la {room_list[1].room_name} que se encuentra al Este, presione [E]
        Si deseas volver al cuarto presione [V]
        --> ''')).lower()
            while not (mover == 'e' or mover == 'v'):
                mover = (input(f''' 
        Si deseas moverte a la {room_list[1].room_name} presione [E]
        Si deseas volver al cuarto presione [V]
        --> ''')).lower()

            if mover == 'e':
                room_1(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)

        elif menu_op == '2':
            touch_object = input(f'''Los objetos que hay en este cuarto son:
        1. {obj_1} ubicado en el centro de la {room_2}, ojo para pisar el {obj_1} tienes que estar graduado sino pierdes vidas
        2. {obj_2} ubicado a la izquierda de la {room_2}
        3. {obj_3} ubicado a la derecha de la {room_2}
        4. Volver a la {room_2}
        --> ''')

            while not(touch_object.isnumeric()) or int(touch_object) not in range(1,5):
                touch_object = input(f'''
        Indique el numero del objeto que desea tocar:
        1. {obj_1} ubicado en el centro de la {room_2}
        2. {obj_2} ubicado a la izquierda de la {room_2}
        3. {obj_3} ubicado a la derecha de la {room_2}
        4. Volver a la {room_2}
        --> ''')
            if touch_object == '1':
                print(f'Es hora de jugar {game_1} para que puedas ganar un {award_1}\nOjo, pierdes una vida por pisar el saman, pero si tienes {requirement_1} puedes jugar \nBuena Suerte!\n')
                if 'Titulo Universitario' in recompensas_list and 'Mensaje' in recompensas_list:
                    gano = encuentra_logica_main(gano)
                    if gano:
                        recompensas_list.append(award_1)
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print('NOOOO, No estas graduado, no puedes pisar el Samán')
                    print(f'No tienes {requirement_1} en tu lista de recompensas para poder jugar {game_1}\nPara poder ganarlo debes jugar {games[5]} que está en el cuarto {room_list[1].room_name}, en {obje[5]} y {games[12]}, que está en el cuarto {room_list[4].room_name}, el {obje[12]}')
                    print('Hasta que no tengas lo que necesitas no vuelvas porque pierdes vidas')
                    vidas -= 1
            elif touch_object == '2':
                print(f'Es hora de jugar {game_2} para que puedas ganar un {award_2}\nOjo, pierdes media vida por opción incorrecta o por acabarse el tiempo\nBuena Suerte!\n')
                vidas, pistas, gano = quizziz_main(vidas, pistas, gano)
                if gano:
                    recompensas_list.append(award_2)
                else:
                    if vidas <= 0:
                        win = False
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(username, password, age, avatar, time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        sys.exit()

            elif touch_object == '3':
                print(f'Es hora de jugar {game_3} para que puedas ganar un {award_3}\nOjo, pierdes un cuarto de vida por elección incorrecta\nBuena Suerte!\n')
                vidas, gano = memoria_emojis_main(vidas, gano)
                if gano:
                    recompensas_list.append(award_3)
                else:
                    if vidas <= 0:
                        win = False
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(username, password, age, avatar, time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        sys.exit()
        
        elif menu_op == '3':
            print(f'Las recompensas que tienes hasta ahora son:\n{recompensas_list}\n')

        elif menu_op == '4':
            print(f'Te quedan {pistas} pistas')

        elif menu_op == '5':
            print(f'Te quedan {vidas} vidas')

        else:
            break
    
    return vidas, pistas, partidas

def room_3(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar):
    room_3 = room_list[3].room_name
    obj_1 = (obje[9]).title()
    game_1 = (games[9]).title()
    award_1 = awards[9]
    requirement_1 = requir[9]
    gano = False
    print(f'''
                     --{room_3}-- 
     ----------------------------------------------------
    |                                                    |
    |                                                    |    
    |                                                    |   
    |                   ---------------                  |
    |                  |    PUERTA     |                 |         
    |                   ---------------                  |                     
    |                                                    |       
    |                                                    |      
    |                                                    |     
    |                                                    |
     ----------------------------------------------------
    ''')
    while True:
        print(f'Te encuentras en {room_3}')
        menu = input('Para ver el menu presione [1]: ')
        while not (menu.isnumeric()) or int(menu) != 1:
            menu = input('Para ver el menu de lo que puedes hacer presiona [1]: ')

        menu_op = input('''
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')

        while not (menu_op.isnumeric()) or int(menu_op) not in range(1,7):
            menu_op = input('''
            Ingrese el numero de la accion que desea realizar
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')
        if menu_op == '1':
            mover = (input(f'''Actualmente te encuentras en el {room_3}, te puedes mover a:
            [E]. {room_list[1].room_name} al este del {room_3}
            [O]. {room_list[0].room_name} al oeste del {room_3}
            [V]. Volver al cuarto
            --> ''')).lower()
            while not (mover == 'e' or mover == 'o' or mover == 'v'):
                mover = (input(f'''Indique la direccion del cuarto al que se quiere mover:
            [E]. {room_list[1].room_name} al este del {room_3}
            [O]. {room_list[0].room_name} al oeste del {room_3}
            [V]. Volver al cuarto
            --> ''')).lower()
            if mover == 'e':
                room_1(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)

            elif mover == 'o':
                room_4(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)


        elif menu_op == '2':
            touch_object = input(f'''En este cuarto solo hay un objeto:
        1. {obj_1} ubicado en el centro del {room_3}
        2. Volver al {room_3}
        --> ''')

            while not(touch_object.isnumeric()) or int(touch_object) not in range(1,3):
                touch_object = input(f'''Indica el numero del objeto o de volver al cuarto:
        1. {obj_1} ubicado en el centro del {room_3}
        2. Volver al {room_3}
        --> ''')
            if touch_object == '1':
                print(f'Es hora de jugar el {game_1} para que puedas ganar un {award_1}\nPara jugar debes de tener un {requirement_1} en tu inventario\nOjo, pierdes media vida por respuesta incorrecta\nBuena Suerte!\n')
                if requirement_1 in recompensas_list:
                    vidas, gano = logica_booleana_main(vidas, gano)
                    if gano == True:
                        recompensas_list.append(award_1)
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print(f'No tienes {requirement_1} en tu lista de recompensas para poder jugar {game_1}\nPara poder ganarlo debes jugar {games[8]} que está en el cuarto {room_list[2].room_name}, en {obje[8]}\n')


        elif menu_op == '3':
            print(f'Las recompensas que tienes hasta ahora son:\n{recompensas_list}\n')

        elif menu_op == '4':
            print(f'Te quedan {pistas} pistas')

        elif menu_op == '5':
            print(f'Te quedan {vidas} vidas')

        else:
            break
    
    return vidas, pistas, partidas

def room_4(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar):
    room_4 = room_list[0].room_name
    obj_1 = (obje[0]).title()
    game_1 = (games[0]).title()
    award_1 = awards[0]
    requirement_1 = requir[0]
    obj_2 = (obje[1]).title()
    game_2 = (games[1]).title()
    award_2 = awards[1]
    requirement_2 = requir[1]
    obj_3 = (obje[2]).title()
    game_3 = (games[2]).title()
    award_3 = awards[2]
    requirement_3 = requir[2]
    gano = False
    print(f'''
                    ----{room_4}---- 
     ----------------------------------------------------
    |                                                    |
    |   ---------------                                  |    
    |  | Computadora 1 |                                 |   
    |   ---------------     -----------                  |
    |                      |  PIZARRA  |                 |         
    |                       -----------                  |                     
    |                                   ---------------  |       
    |                                  | Computadora 2 | |      
    |                                   ---------------  |     
    |                                                    |
     ----------------------------------------------------
    ''')
    while True:
        print(f'Te encuentras en {room_4}')
        menu = input('Para ver el menu presione [1]: ')
        while not (menu.isnumeric()) or int(menu) != 1:
            menu = input('Para ver el menu de lo que puedes hacer presiona [1]: ')

        menu_op = input('''
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')

        while not (menu_op.isnumeric()) or int(menu_op) not in range(1,7):
            menu_op = input('''
            Ingrese el numero de la accion que desea realizar
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Guardar en el inventario alguna recompensa
        4. Usar alguna recompensa para desbloquear algun reto
        5. Usar alguna pista
        6. Salir
        --> ''')
        if menu_op == '1':
            mover = (input(f'''Actualmente te encuentras en los {room_4}, te puedes mover a:
            [E]. {room_list[3].room_name} ubicado al este de los {room_4}
            [O]. {room_list[4].room_name} ubicado al oeste de los {room_4}
            [V]. Volver al cuarto
            --> ''')).lower()
            while not (mover == 'e' or mover == 'o' or mover == 'v'):
                mover = (input(f'''Indique la direccion del cuarto al que se quiere mover:
            [E]. {room_list[3].room_name} ubicado al este de los {room_4}
            [O]. {room_list[4].room_name} ubicado al oeste de los {room_4}
            [V]. Volver al cuarto
            --> ''')).lower()
            if mover == 'e':
                room_3(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)

            elif mover == 'o':
                room_5(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)

        elif menu_op == '2':
            touch_object = input(f'''Los objetos que hay en este cuarto son:
        1. {obj_1} ubicado en el centro de los {room_4}
        2. {obj_2} ubicado a la izquierda de los {room_4}
        3. {obj_3} ubicado a la derecha de los {room_4}
        4. Volver a los {room_4}
        --> ''')

            while not(touch_object.isnumeric()) or int(touch_object) not in range(1,5):
                touch_object = input(f'''
        Indique el numero del objeto que desea tocar:
        1. {obj_1} ubicado en el centro de los {room_4}
        2. {obj_2} ubicado a la izquierda de los {room_4}
        3. {obj_3} ubicado a la derecha de los {room_4}
        4. Volver a los {room_4}
        --> ''')
            if touch_object == '1':
                print(f'Es hora de jugar {game_1} para que puedas ganar una {award_1}\nPierdes media vida por palabra incorrecta\nBuena Suerte!\n')
                vidas, pistas, gano = sopa_letras_main(vidas, pistas, gano)
                if gano:
                    vidas += 1
                else:
                    if vidas <= 0:
                        win = False
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(username, password, age, avatar, time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        sys.exit()

            elif touch_object == '2':
                print(f'Es hora de jugar {game_2} para que puedas ganar un {award_2}\nPara poder jugar necesitas un {requirement_2} \nPierdes media vida por respuesta incorrecta\nBuena Suerte!\n')
                if requirement_2 in recompensas_list:
                    vidas, pistas, gano = preguntas_py_main(vidas, pistas, gano)
                    if gano == True:
                        recompensas_list.append(award_2)
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print(f'No tienes el {requirement_2} en tu lista de recompensas para poder jugar {game_2}\nPara poder ganarlo debes jugar {games[3]} que está en el cuarto {room_list[1].room_name}, en {obje[3]}')


            elif touch_object == '3':
                print(f'Es hora de jugar {game_3} para que puedas ganar una {award_3}\nPara poder jugar debes {requirement_3} \nPierdes media vida por respuesta incorrecta\nBuena Suerte!\n')
                if 'contraseña' in recompensas_list:
                    vidas, pistas, gano = adivinanzas_main(vidas, pistas, gano)
                    if gano == True:
                        recompensas_list.append(award_3)
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print(f'No tienes {requirement_3} en tu lista de recompensas para poder jugar {game_3}\nPara poder ganarlo debes jugar {games[11]} que está en el cuarto {room_list[4].room_name}, en {obje[11]}')

        
        elif menu_op == '3':
            print(f'Las recompensas que tienes hasta ahora son:\n{recompensas_list}\n')

        elif menu_op == '4':
            print(f'Te quedan {pistas} pistas')

        elif menu_op == '5':
            print(f'Te quedan {vidas} vidas')

        else:
            break
    return vidas, pistas, partidas

def room_5(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar):
    room_5 = room_list[4].room_name
    obj_1 = (obje[10]).title()
    game_1 = (games[10]).title()
    award_1 = awards[10]
    requirement_1 = requir[10]
    obj_2 = (obje[11]).title()
    game_2 = (games[11]).title()
    award_2 = awards[11]
    requirement_2 = requir[11]
    obj_3 = (obje[12]).title()
    game_3 = (games[12]).title()
    award_3 = awards[12]
    requirement_3 = requir[12]
    gano = False
    print(f'''
                    ----{room_5}---- 
     ----------------------------------------------------
    |                                                    |
    |   --------                                         |    
    |  |  RACK  |                                        |   
    |   --------         -----------                     |
    |                   |  PUERTA   |                    |         
    |                    -----------                     |                     
    |                                   ----------       |       
    |                                  | Papelera |      |      
    |                                   ----------       |     
    |                                                    |
     ----------------------------------------------------
    ''')
    while True:
        print(f'Te encuentras en {room_5}')
        menu = input('Para ver el menu presione [1]: ')
        while not (menu.isnumeric()) or int(menu) != 1:
            menu = input('Para ver el menu de lo que puedes hacer presiona [1]: ')

        menu_op = input('''
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Ver la lista de recompensas
        4. Ver cuatas pistas me quedan
        5. Ver cuantas vidas tengo
        6. Salir
        --> ''')

        while not (menu_op.isnumeric()) or int(menu_op) not in range(1,7):
            menu_op = input('''
            Ingrese el numero de la accion que desea realizar
        1. Moverse a otro cuarto
        2. Tocar algun objeto en la habitacion donde estas
        3. Guardar en el inventario alguna recompensa
        4. Usar alguna recompensa para desbloquear algun reto
        5. Usar alguna pista
        6. Salir
        --> ''')
        if menu_op == '1':
            mover = (input(f'''Actualmente te encuentras en el {room_5}, te puedes mover a:
            [E]. {room_list[0].room_name} ubicado al este del {room_5}
            [V]. Volver al cuarto
            --> ''')).lower()
            while not (mover == 'e' or mover == 'o' or mover == 'v'):
                mover = (input(f'''Actualmente te encuentras en el {room_5}, te puedes mover a:
            [E]. {room_list[0].room_name} ubicado al Este del {room_5}
            [V]. Volver al cuarto
            --> ''')).lower()
            if mover == 'e':
                room_4(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)


        elif menu_op == '2':
            touch_object = input(f'''Los objetos que hay en este cuarto son:
        1. {obj_1} ubicado en el centro del {room_5}
        2. {obj_2} ubicado a la izquierda del {room_5}
        3. {obj_3} ubicado a la derecha del {room_5}
        4. Volver al {room_5}
        --> ''')

            while not(touch_object.isnumeric()) or int(touch_object) not in range(1,5):
                touch_object = input(f'''
        Indique el numero del objeto que desea tocar:
        1. {obj_1} ubicado en el centro del {room_5}
        2. {obj_2} ubicado a la izquierda del {room_5}
        3. {obj_3} ubicado a la derecha del {room_5}
        4. Volver al {room_5}
        --> ''')
            if touch_object == '1':
                print(f'Es hora de jugar a completar el refrán para que ganes el juego\nPierdes una vida por cada refrán incorrecto\n')
                if 'carnet' in recompensas_list and 'Disco Duro' in recompensas_list:
                    vidas, gano = completa_refran_main(vidas, gano)
                    if gano:
                        win = True
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(username, password, age, avatar, time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        print(f'Felicidades, lograste devolver el disco duro en un tiempo de {time_x_partida}')
                        sys.exit()
                    else:
                        if vidas <= 0:
                            win = False
                            end = time.monotonic()
                            time_x_partida = end - start
                            partida = Partida(username, password, age, avatar, time_x_partida, win)
                            partidas.append(partida)
                            cargar_txt('partidas.txt', partidas)
                            sys.exit()
                else:
                    print(f'No tienes {requirement_1} en tu lista de recompensas para poder jugar {game_1}\nPara poder ganarlo debes jugar {games[2]} que está en el cuarto {room_list[0].room_name}, en {obje[2]} y {games[6]} en el cuarto {room_list[2].room_name} en {obje[6]}')

                

            elif touch_object == '2':
                print(f'Es hora de jugar {game_2} para que ganes la {award_2}\nPierdes media vida por cada palabra incorrecta\n')
                vidas, gano = palabra_mezclada_main(vidas, gano)
                if gano:
                    recompensas_list.append(award_2)
                else:
                    if vidas <= 0:
                        win = False
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        sys.exit()

            elif touch_object == '3':
                print(f'Es hora de jugar {game_3} para que ganes el {award_3}\nPierdes 0,1 vida por intento fallando\n')
                vidas, gano = pick_num_main(vidas, gano)
                if gano:
                    recompensas_list.append('Titulo Universitario')
                else:
                    if vidas <= 0:
                        win = False
                        end = time.monotonic()
                        time_x_partida = end - start
                        partida = Partida(time_x_partida, win)
                        partidas.append(partida)
                        cargar_txt('partidas.txt', partidas)
                        sys.exit()
        
        elif menu_op == '3':
            print(f'Las recompensas que tienes hasta ahora son:\n{recompensas_list}\n')

        elif menu_op == '4':
            print(f'Te quedan {pistas} pistas')

        elif menu_op == '5':
            print(f'Te quedan {vidas} vidas')

        else:
            break
    return vidas, pistas, partidas

#main para los cuartos
def api(vidas, pistas, partidas, start, username, password, age, avatar):
    #Importar la api
    url = 'https://api-escapamet.vercel.app/'
    response = requests.get(url)
    response = response.json()
    
    recompensas_list = []
    room_list = []
    #recorrer la api por el key 
    for room in response:
        room_name = room['name']

        lista_objetos = []
       
        for object in room['objects']:
      
            object_name = object['name']
            position = object['position']

            requirement = object['game']['requirement']
            game_name = object['game']['name']
            award = object['game']['award']
            rules = object['game']['rules']

            questions = object['game']['questions']

            objetoTemp = Objeto(object_name, position, requirement, game_name, award, rules, questions)

            lista_objetos.append(objetoTemp)
       
        roomTemp = Room(room_name, lista_objetos)

        room_list.append(roomTemp)

    #lista para guardar solo el nombre de los objetos
    obje = []
    #lista para guardar los juegos de los objetos 
    games = []
    awards = []
    rules = []
    requir = []
    #info = []
    for r in room_list:
        for o in r.lista_objetos:
            objetos = o.object_name
            obje.append(objetos)
        for g in r.lista_objetos:
            juegos = g.game_name
            games.append(juegos) 
        for q in r.lista_objetos:
            inf = q.questions
        for a in r.lista_objetos:
            award = a.award
            awards.append(award)
        for ru in r.lista_objetos:
            rule = ru.rules
            rules.append(rule)
        for re in r.lista_objetos:
            requ = re.requirement
            requir.append(requ)

    info = []
    for r in room_list:
        for q in r.lista_objetos:
            inf = q.questions
            info.append(inf)
#llamar al primer cuarto
    room_1(room_list, lista_objetos, obje, games, awards, rules, requir, recompensas_list, vidas, pistas, partidas, start, username, password, age, avatar)
    return vidas, pistas, partidas
