import random

def pick_question(questions_list):
    random_question = random.choice(questions_list)
    return random_question

def preguntas_py_main(vidas, pistas, gano):
    pistas_completas = pistas
    pistas2 = pistas - 1
    pistas3 = pistas2 - 1
    pista_op2 = 1
    questions_list = ["Tengo el siguiente string: frase  = \"tengo en mi cuenta 50,00 $\". Escribe en una línea de código como extraer de este string los 50 en formato entero", "Invierte este string con python en un línea  para poder leerlo frase = \'oidutse ne al ortem aireinegni ed sametsis\'"]
    question = pick_question(questions_list)      
    print('''
-----PREGUNTAS SOBRE PYTHON-----
Debes usar tus conocimientos de python para resolver la siguente pregunta
Buena Suerte!''')
    while True:
        print()
        print(question)
        print()
        if question == questions_list[0]:
            clue_1 = 'utiliza replace'
            clue_2 = 'utiliza float'
            clue_3 = 'utiliza int'  
            print('''Debe ingresar en una línea el código
Partiendo de n = '50,00'
Debe ingresar los cambios que se le harán a n separando las líneas de codigo con [,] y sin volver a igualar n
Ej. codigo_linea1, codigo_linea2, codigo_linea3
''')
            resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
            print()
            while not (resp_clue.isnumeric()) or int(resp_clue) not in range(1,3):
              resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
            if resp_clue == '1':
                code = input('Ingrese su línea con el codigo: ')
                n = '50,00'
                n = n.replace(',', '.')
                n = float(n)
                n = int(n)
                answer = "n.replace(',', '.'), float(n), int(n)" 
                if code == answer:
                    print('Felicidades, acertaste el código')
                    gano = True
                    break
                else:
                    ('\nEse no es el código correcto, sigue intentando, acabas de perder media vida')
                    vidas -= 1/2
                    if vidas <= 0:
                        print('\nSe te acabaron las vidas')
                        gano = False
                        break
            else:
                if pistas != 0:
                    if pistas == pistas_completas:
                        print(f'PISTA: {clue_1}')
                        pistas -= 1
                    elif pistas == pistas2:
                        print(f'PISTA: {clue_2}')
                        pistas -= 1
                    elif pistas == pistas3:
                        print(f'PISTA: {clue_3}')
                        pistas -= 1
                else:
                  print('No te quedan más pistas')
        else:
            resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
            print()
            while not (resp_clue.isnumeric()) or int(resp_clue) not in range(1,3):
              resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
            if resp_clue == '1':
                frase = "oidutse ne al ortem aireinegni ed sametsis"
                answer = "estudio en la metro ingenieria de sistemas"
                string_invertido = (input('Debes escribir el string invertido: ')).lower()
                if string_invertido == answer:
                    print('\nFelicidades, esa es la frase') 
                    gano = True
                    break
                else:
                    print('\nMmmm, frase incorrecta, perdiste media vida, vuelve a intentar')
                    vidas -= 1,2
                if vidas == 0:
                    print('Se te acabadron las vidas')
                    gano = False
                    break
            else:
                if pistas != 0:
                    if pista_op2 !=0:
                        if pistas == pistas_completas:
                            print(f'PISTA: utiliza slices')
                            pistas -= 1
                            pista_op2 -= 1
                        else:
                            print('No hay mas pistas')
                else:
                  print('No te quedan más pistas')

    return vidas, pistas, gano