import re
from Jugador import * 
from rooms import *
import json
import time

def timer(tiempo):
    min = tiempo //60
    sec = tiempo % 60
    timer = '{:02d}:{:02d}'.format(min, sec)
    print(timer, end='\r')
    tiempo -= 1

#funcion para escoger la dificultad del juego
def dificultad(vidas, pistas, tiempo_min, tiempo_seg):
    with open('data.json') as file:
        data = json.load(file)
    dificultades = data['dificultad']
    info_dif1 = dificultades[0]
    vidas1 = info_dif1['vidas']
    pistas1 = info_dif1['pistas']
    tiempo1_seg = info_dif1['tiempo_segundos']
    tiempo1_min = info_dif1['tiempo_minutos']

    info_dif2 = dificultades[1]
    vidas2 = info_dif2['vidas']
    pistas2 = info_dif2['pistas']
    tiempo2_seg = info_dif2['tiempo_segundos']
    tiempo2_min = info_dif2['tiempo_minutos']

    info_dif3 = dificultades[2]
    vidas3 = info_dif3['vidas']
    pistas3 = info_dif3['pistas']
    tiempo3_seg = info_dif3['tiempo_segundos']
    tiempo3_min = info_dif3['tiempo_minutos']
    
    dificultad = input('''
    Indique el nivel de dificultal:
    1. Facil
    2. Medio
    3. Dificil
    --> ''')
    while not (dificultad.isnumeric()) or int(dificultad) not in range(1, 4):
        dificultad = input('''
    Indique el nivel de dificultal por su numero:
    1. Facil
    2. Medio
    3. Dificil
    --> ''')

    if dificultad == '1':
        vidas = vidas1
        pistas = pistas1
        tiempo_seg = tiempo1_seg
        tiempo_min = tiempo1_min

    elif dificultad == '2':
        vidas = vidas2
        pistas = pistas2
        tiempo_seg = tiempo2_seg
        tiempo_min = tiempo2_min

    else:
        vidas = vidas3
        pistas = pistas3
        tiempo_seg = tiempo3_seg
        tiempo_min = tiempo3_min

    return vidas, pistas, tiempo_min, tiempo_seg

def jugar(partidas, username, password, age, avatar):
    vidas = 0
    pistas = 0
    tiempo_min = 0
    tiempo_seg = 0
    vidas, pistas, tiempo_min, tiempo_seg = dificultad(vidas, pistas, tiempo_min, tiempo_seg)
    jugar = 's' 
    #se va a jugar mientras se acepte el reto
    
    while jugar == 's':
        print(f'''
        Hoy 5 de marzo de 2021, la Universidad sigue en cuarentena (esto no es novedad), lo que sí es novedad es que se robaron un Disco Duro de la Universidad del cuarto de redes que tiene toda la información de SAP de estudiantes, pagos y asignaturas. Necesitamos que nos ayudes a recuperar el disco, para eso tienes {tiempo_min} minutos, antes de que el servidor se caiga y no se pueda hacer más nada. ¿Aceptas el reto?
        ''')
        jugar = (input('''
        [S]Si, [N]No
        --> ''')).lower()
        if jugar == 's':
            start = time.monotonic()
            for i in range(1500):
                print(f'''​Bienvenido, gracias por tu disposición a ayudarnos a resolver este inconveniente, te encuentras actualmente ubicado en la biblioteca, revisa el menú de opciones para ver qué acciones puedes realizar. Recuerda que el tiempo corre más rápido que un trimestre en este reto.
        ''')
                vidas, pistas, partidas, start, username, password, age, avatar = api(vidas, pistas, partidas, start, username, password, age, avatar)
            end = time.monotonic()
            tiempo_transcurrido = end - start
            if tiempo_transcurrido > tiempo_seg:
                print('Se te acabo el tiempo, perdiste')
                jugar = 'n'
                break

#crear un usuario nuevo con nombre, clave, edad y avatar
def new_username(usuarios):
    username = input('''
El nombre de usuario no puede contener mas de 15 caracteres ni espacios.
Ingrese el nombre de usuario: ''')
    
    #validar los requerimientos del username
    while len(username) >= 15 or re.search(' ', username):
        username = input('''El nombre de usuario no puede contener mas de 15 caracteres ni espacios
Ingrese un nombre de usuario valido: ''')
    
    #validar que no exista ese usuario 
    for u in range(len(usuarios)):
        usuario = (u, usuarios[u].username)
        while username in usuario:
            username = input('''El nombre de usuario ingresado ya existe.
Por favor ingrese un nombre de usuario nuevo: ''')
    password = input('''
Su contraseña no puede tener espacios y debe de contener un minimo de 8 caracteres y al menos un numero
Ingrese su contraseña: ''')
    
    #validar los requerimientos de la contrasena
    while len(password)<8 or (not re.search('[0-9]', password)) or re.search(' ', password):
        password = input('''Su contraseña no puede tener espacios y debe de contener un minimo de 8 caracteres y al menos un numero
Ingrese una contraseña valida: ''')

    #ingresar edad
    age = input('Ingrese su edad: ')
    while not (age.isnumeric()) or int(age) == 0:
        age = input('Ingrese una edad valida: ')
    
    #elegir avatar
    avatar = input('''
    Que avatar desea ser:
    1. Scharifker
    2. Eugenio Mendoza
    3. Pelusa
    4. Gandhi
    --> ''')
    while not (avatar.isnumeric()) or int(avatar) not in range(1, 5):
        avatar = input('Ingrese el número del avatar: ')
    if avatar == "1":
        avatar = 'Scharifker'
    elif avatar == '2':
        avatar = 'Eugenio Mendoza'
    elif avatar == '3':
        avatar = 'Pelusa'
    else:
        avatar = 'Gandhi'
    
    #se agrega la informacion del usuario a la clase
    usuario = Jugador(username, password, age, avatar)
    usuarios.append(usuario)
    return usuarios
