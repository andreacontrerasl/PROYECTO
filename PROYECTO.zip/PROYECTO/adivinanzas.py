import random

def pick_adivinanza(adivinanza_list):
    random_adivinanza = random.choice(adivinanza_list)
    return random_adivinanza

def adivinanzas_main(vidas, pistas, gano):
    adivinanza_list = ["Soy alta cuando soy joven y baja cuando soy vieja. ¿Qué soy yo?", "Es pequeño como una pera, pero alumbra la casa entera. ¿Qué soy yo?", "Oro parece y plata no es, y no lo adivinas de aquí a un mes ¿Qué soy yo?"]
    adivinanza = pick_adivinanza(adivinanza_list)
    if adivinanza == adivinanza_list[0]:
        answer = ['una vela', 'vela', 'la vela']
        clue_1 = 'lo usas cuando se va la luz'
        clue_2 = 'lo puedes prender con un encendedor'
        clue_3 = 'es de cera'
    elif adivinanza == adivinanza_list[1]:
        answer = ['un bombillo', 'el bombillo', 'bombillo']
        clue_1 = 'lo usas cuando hay luz'
        clue_2 = 'gracias a estar encendido puedes leer'
        clue_3 = 'se coloca en las lámparas'
    else:
        answer = ['platano', 'el platano', 'un platano', 'plátano', 'el plátano', 'un plátano']
        clue_1 = 'fruta'
        clue_2 = 'POTASIO'
        clue_3 = 'parecido al cambur'
    pistas_completas = pistas
    pistas2 = pistas - 1
    pistas3 = pistas2 - 1
    print('''
-----BIENVENIDO A LAS ADIVINANZAS-----
    Se le mostrará una adivnanza y deberas adivinar lo que es''')

    while True:
        print(f'\n{adivinanza}\n')
        resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
        print()
        while not (resp_clue.isnumeric()) or int(resp_clue) not in range(1,3):
          resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
        if resp_clue == '1':
            adivinar = (input('Ingrese la respuesta: ')).lower()
            if adivinar in answer:
                print('Felicidades, ganaste!')
                gano = True
                break
            else:
                print('Respuesta incorrecta, vuelve a intentarlo, recuerda que estas perdiendo vidas así que piensa bien')
                vidas -= 1/2
                if vidas <= 0:
                    print('Se te acabaron las vidas')
                    gano = False
                    break
        else:
            print()
            if pistas != 0:
                if pistas == pistas_completas:
                    print(f'PISTA: {clue_1}')
                    pistas -= 1
                elif pistas == pistas2:
                    print(f'PISTA: {clue_2}')
                    pistas -= 1
                elif pistas == pistas3:
                    print(f'PISTA: {clue_3}')
                    pistas -= 1
            else:
              print('No te quedan más pistas')

    return vidas, pistas, gano

#adivinanzas_main()