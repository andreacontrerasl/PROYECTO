import json
#Informacion para convertin en JSON donde se guardan las vidas, tiempo y pistas
data = {}
data['dificultad'] = []
data['dificultad'].append({
    'vidas': 5,
    'pistas': 5,
    'tiempo_segundos': 1500,
    'tiempo_minutos': 25})
data['dificultad'].append({
    'vidas': 3,
    'pistas': 3,
    'tiempo_segundos': 1200, 
    'tiempo_minutos': 20})
data['dificultad'].append({
    'vidas': 1,
    'pistas': 2,
    'tiempo_segundos': 900,
    'tiempo_minutos': 15})
with open('data.json', 'w') as file:
    json.dump(data, file, indent=3)