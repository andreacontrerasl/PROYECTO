from funciones_proyecto import *
import pickle
from llamar_text import *

def estadisticas(partidas):
    partidas.sort(key = lambda partida: partida.time_x_partida, reverse = False)
    for i,partida in enumerate(partidas):
        if i < 5:
            print('Top 5 mejores tiempos')
            print("-------",i+1,"-------")
            print(partida.mostrar())


#chequear que la persona tenga su cuenta y llamar a la funcion para comenzar el juego
def check_username(usuarios, partidas):
    existe = False
    #Pedir los datos del usuario
    nombre_usuario = input('Ingrese su nombre de usuario: ')
    clave = input('Ingrese su clave: ')
    #Crear una tupla con el nombre de usuario y la clave del usuario
    cuenta = (nombre_usuario, clave)
    #Lista vacia para la cuneta
    account = []
    #recorrer la lista de usuarios para chequear que los datos del usuario esten correctos 
    for u in range(len(usuarios)):
        #variables para nombrar y acceder al username y la clave de la clase Jugador
        username = usuarios[u].username
        password = usuarios[u].password
        cuenta_check = (username, password)
        account.append(cuenta_check)
        while not cuenta in account:
            nombre_usuario = input('El nombre de usuario ingresado no existe. Ingrese un nombre de usuario valido: ')
            clave = input('Clave incorrecta. Ingrese su clave: ')
        if cuenta_check in account:
            age = usuarios[u].age
            avatar = usuarios[u].avatar
            existe = True

    if existe:
        partidas = jugar(partidas, username, password, age, avatar)

#para empezar una partida
def new_game(usuarios, partidas): 
    op = input('''
    1. Registrarse
    2. Ingresar
    --> ''')
    while not (op.isnumeric()) or int(op) not in range(1, 3):
        op = input('''
    Ingrese el numero correspondiente
    1. Registrarse
    2. Ingresar
    --> ''') 
    #Crear un nuevo usuario
    if op == '1': 
        usuarios = new_username(usuarios)
        cargar_txt('usuarios.txt', usuarios)
        
    #Si la persona tiene un usuario, chequear que sea el
    else: 
        check_username(usuarios, partidas)
        
#  introduccion al juego/bienvenida
def main():
    usuarios = []
    partidas = []
    #nombrar a la funcion que lee el txt
    usuarios = recibir_txt('usuarios.txt', usuarios)
    partidas = recibir_txt('partidas.txt', partidas)
    while True:
        print('''
---BIENVENIDO AL ESCAPE-ROOM UNIMET---
    1. Comenzar una partida nueva
    2. Ver las instrucciones del juego
    3. Ver los records del juego
    ''')
        opcion1 = input('Ingrese el numero de lo que desee hacer: ')
        while not (opcion1.isnumeric()) or int(opcion1) not in range(1, 4):
            opcion1 = input('Debe ingresar uno de los numeros del menú: ')
        if opcion1 == '1': 
            new_game(usuarios, partidas)

        elif opcion1 == '2':
            print('''
------INSTRUCCIONES ECAPE-ROOM UNIMET------
El juego consiste en resolver los distintos juegos que se encuentran en cada objeto de las habitaciones para ir recolectando premios y así poder avanzar entre cuartos y juegos hasta llegar al cuarto de servidores donde deberás resolver los últimos juegos para ganar. 

Hay un total de 5 cuartos, en cada cuarto hay tres objetos y cada uno de esos objetos tiene un juego que deberás jugar para recuperar el disco duro. 
Dependiendo de la dificultad que escojas, tienes un lapso de tiempo en donde podrás completar todo el escape-room, si ese tiempo se termina pierdes, además tienes una cantidad de vidas que las puedes perder cada vez que te equivoques en un juego, pero también las puedes ganar en otros. También tienes una serie de pistas que podrás utilizar en los juegos para lograr completar el nivel.

Debes recorrer todos los cuartos y sus objetos para recolectar todo lo necesario para poder devolver el disco duro en el menor tiempo posible. Mucha suerte 
''')

        else:
            estadisticas(partidas)


main()