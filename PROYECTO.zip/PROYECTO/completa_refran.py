import random

def completa_refran_main(vidas, gano):
    refranes_list = [['g---- -  figura  h---- --  s-p---ur-', '-- p--, --n y a- v---, -—-o', 'a- --- a b--- arb-- se a---ma ---na s----a -- cobija'], ['-- hom--e -- como -- o--, mien---- m-- feo --s he---so', 'martes, ni te ----s n- -e em------s, ni d- t- fa----a -- a---tes', 'b-----a llena, c-----n ------to'], ['el --- a hi---o --ta, - -ie--o m--re', 'la ex---c--- h--e -- -e-la', 'c-d- l-dr-- --zga --- s- co--ic--n']]
    refranes = random.choice(refranes_list)
    if refranes == refranes_list[0]:
        answers = ['genio y figura hasta la sepultura', 'al pan, pan y al vino, vino', 'al que a buen arbol se arrima buena sombra lo cobija']
    elif refranes == refranes_list[1]:
        answers = ['el hombre es como el oso, mientras mas feo mas hermoso', 'martes, ni te cases ni te embarques, ni de tu familia te apartes', 'barriga llena, corazon contento']
    else:
        answers = ['el que a hierro mata, a hierro muere', 'la excepcion hace la regla', 'cada ladron juzga por su condicion']
    
    respuestas = len(refranes)
    print('''
-----ADIVINA Y COMPLETA EL REFRAN-----
Debes adivinar y escribir cada refrán que te aparezca, son tres
Buena suerte''')
    while True:
        print()
        print(refranes[0])
        print()
        respuesta1 = (input('Ingrese el refrán: ')).lower()
        if 'á' in respuesta1:
            respuesta1 = respuesta1.replace('á', 'a')
        while not (respuesta1 == answers[0]):
            print('\nMmm... ese no es el refrán, vuelve a intentarlo')
            vidas -= 1
            respuesta1 = (input('Ingrese el refrán: ')).lower()
        if respuesta1 == answers[0]:
            print(f'Adivinaste el refrán {answers[0]}')
            respuestas -= 1
        print()
        print(refranes[1])
        print()
        respuesta2 = (input('Ingrese el refrán: ')).lower()
        if 'ó' in respuesta2:
            respuesta2 = respuesta2.replace('ó', 'o')
        while not (respuesta2 == answers[1]):
            print('\nMmm... ese no es el refrán, vuelve a intentarlo')
            vidas -= 1
            respuesta2 = (input('Ingrese el refrán: ')).lower()
        if respuesta2 == answers[1]:
            print(f'Adivinaste el refrán {answers[1]}')
            respuestas -= 1
        print()
        print(refranes[2])
        print()
        respuesta3 = (input('Ingrese el refrán: ')).lower()
        if 'ó' in respuesta3:
            respuesta3 = respuesta3.replace('ó', 'o')
        elif 'á' in respuesta3:
            respuesta3 = respuesta3.replace('á', 'a')
        while not (respuesta3 == answers[2]):
            print('\nMmm... ese no es el refrán, vuelve a intentarlo')
            vidas -= 1
            if vidas <= 0:
                print('Se te acabaron las vidas')
                gano = False
                break
            respuesta3 = (input('Ingrese el refrán: ')).lower()
        if respuesta3 == answers[2]:
            print(f'Adivinaste el refrán {answers[2]}')
            respuestas -= 1
        
        if respuestas == 0:
            print('\nFelicidades, adivinaste todos los refranes')
            gano = True
            break

    return vidas, gano
