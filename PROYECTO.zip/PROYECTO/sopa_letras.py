
import random
from Posicion import *

def sopa_letras_main(vidas, pistas, gano):
    pistas_completas = pistas
    pistas2 = pistas - 1
    pistas3 = pistas2 - 1
    words_list = [["pilar", "ardila", "scharifker"], ["bello", "marcano", "dagama"], ["boada", "llorante", "dagama"]]
    #Escoger las palabras random
    words = random.choice(words_list)
    nxn = 15
    matrix = Tabla(nxn)
    if words == words_list[0]:
        clue_1 = 'apellido directora de escuela de sistemas'
        clue_2 = 'apellido jefe del CeTIC'
        clue_3 = 'apellido rector Unimet'        
    elif words == words_list[1]:
        clue_1 = 'apellido de profesor Luis'
        clue_2 = 'apellido del profesor Alejandro'
        clue_3 = 'apellido del Presidente de la Unimet'
    else:
        clue_1 = 'apellido del coronel de Seguridad de la Unimet'
        clue_2 = 'apellido del presidente de la FCE-UNIMET'
        clue_3 = 'apellido de Vicerrectora Académica de la Unimet'

    while matrix.free:
        word = words[random.randint(0, len(words) - 1)]
        matrix.put(word)

    num_palabra = len(words)
    while True:
        print(matrix)
        resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
        print()
        while not (resp_clue.isnumeric()) or int(resp_clue) not in range(1,3):
          resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
        if resp_clue == '1':
            posibles_respuestas = []
            for x in matrix.words:
                resp = list(x)
                posibles_respuestas.append(resp)

            respuesta = []
            x1 = input('Ingrese la coordenada x de donde empieza la palabra: ')
            while not (x1.isnumeric()) or int(x1) not in range(0,15):
                x1 = input('Debe ingresar un número válido del 0-14: ')
            x1 = int(x1)
            respuesta.append(x1)
            y1 = input('Ingrese la coordenada y de donde empieza la palabra, debe contar del 0-14: ')
            while not (y1.isnumeric()) or int(y1) not in range(0,15):
                y1 = input('Debe ingresar un número válido del 0-14: ')
            y1 = int(y1)
            respuesta.append(y1)
            palabra_respuesta = (input('Ingrese la palabra: ')).lower()
            respuesta.append(palabra_respuesta)
            print(respuesta)
            if respuesta in posibles_respuestas:
                print('Palabra y posicion correcta')
                num_palabra -= 1

            else:
                print('Palabra o posición incorrecta')
                vidas -= 1/2
                if vidas <= 0:
                    print('\nSe te terminaron las vidas')
                    gano = False
                    break

            if num_palabra == 0:
                print('\nFelicidades ganaste')
                gano = True
                break

        else:
            if pistas != 0:
                if pistas == pistas_completas:
                    print(f'PISTA: {clue_1}')
                    pistas -= 1
                elif pistas == pistas2:
                    print(f'PISTA: {clue_2}')
                    pistas -= 1
                elif pistas == pistas3:
                    print(f'PISTA: {clue_3}')
                    pistas -= 1
            else:
              print('No te quedan más pistas')

    return vidas, pistas, gano 