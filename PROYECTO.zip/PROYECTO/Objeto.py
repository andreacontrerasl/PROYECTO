class Objeto:
    def __init__(self, object_name, position, requirement, game_name, award, rules, questions):

        self.object_name = object_name
        self.position = position
        self.requirement = requirement
        self.game_name = game_name
        self.award = award
        self.rules = rules
        self.questions = questions