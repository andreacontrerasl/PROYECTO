import random

def pick_desplazamiento(desplazamineto_list):
    random_desp = random.choice(desplazamineto_list)
    return random_desp


def criptograma_main(vidas, gano):
    texto = ('Si te graduas pisas el saman').lower()
    desplazamineto_list = [2, 4, 5]
    desplazamineto = pick_desplazamiento(desplazamineto_list)
    cifrado = ''
    letras = 'abcdefghijklmnopqrstuvwxyz'
    if desplazamineto == 2:
        abc = 'cdefghijklmnopqrstuvwxyzab'
    elif desplazamineto == 4:
        abc = 'efghijklmnopqrstuvwxyzabcd'
    else:
        abc = 'fghijklmnopqrstuvwxyzabcde'
    for c in texto:
        if c in letras:
            cifrado += letras[(letras.index(c)+desplazamineto)%(len(letras))]
        else:
            cifrado += c

    print('''
-----BIENVENIDO AL CRIPTOGRAMA-----
    A continuación se le mostrara una frase encriptada la cual debe descifrar utilizando los dos abecedarios dados.
    En este juego no tienes pistas
    Buena Suerte!''')
    while True:
        print(f'\nEl mensaje a descifrar es: {cifrado}\n')
        print(f'El abecedario original es:   {letras}')
        print(f'El abecedario desplazado es: {abc}')
        print('\n')
        frase = (input('Ingrese la frase descifrada: ')).lower()
        if frase == texto:
            print('\nFelicidades ganaste!')
            gano = True
            break
        else: 
            print('\nMmmm... Esa no es la frase, vuelve a intentarlo, pero recuerda que estas perdiendo vidas')
            vidas -= 1
        
            if vidas <= 0:
                print('\nSe te acabaron las vidas, perdiste el juego')
                gano = False
                break
    return vidas, gano
