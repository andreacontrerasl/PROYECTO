import random
import time

def pick_question(questions_list):
    random_question = random.choice(questions_list)
    return random_question

def quizziz_main(vidas, pistas, gano):
    pista_usada = pistas - 1
    correct_answer = ''
    questions_list = ["¿En qué fecha es el Aniversario de la Universidad Metropolitana?", "¿En qué año fue Fundada la Universidad Metropolitana?", "¿Quién fundó la Unimet?"]
    print('''
-----BIENVENIDO AL QUIZZIS DE CULTURA UNIMETANA-----
Se te mostrará una pregunta de seleccion simple y debes escoger la opción correcta
Buena suerte!''')
    question = pick_question(questions_list)

    if question == questions_list[0]:
        opciones = ('''
        a. 22 de octubre
        b. 22 de septiembre
        c. 25 de octubre
        d. 25 de septiembre
        ''')
        correct_answer = 'a'
        clue = 'es en octubre'

    elif question == questions_list[1]:
        opciones = ('''
        a. 1969
        b. 1970
        c. 1980
        d. 1979
        ''')
        correct_answer = 'b'
        clue = 'termina en 0 el año'
    elif question == questions_list[2]:
        opciones = ('''
        a. Lorenzo Mendoza
        b. Rafael Matiezo
        c. Luis Miguel Da Gama
        d. Eugenio Mendoza
        ''')
        correct_answer = 'd'
        clue = 'tiene una estatua'

    while True:
        print(f'\n{question}')
        print(opciones)
        print()
        resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
        print()
        while not (resp_clue.isnumeric()) or int(resp_clue) not in range(1,3):
            resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
        if resp_clue == '1':
            answer = (input('Ingrese la letra de la respuesta correcta: ')).lower()
            while not (answer == 'a' or answer == 'b' or answer == 'c' or answer == 'd'):
                answer = (input('Ingrese una letrea de las opciones para la respuesta correcta: ')).lower()
            if answer == correct_answer:
                print('Felicidades ganaste!')
                gano = True
                break
            else:
                print('\nRespuesta incorrecta, vuelve a intentarlo, recuerda que estas perdiendo vidas así que piensa bien')
                vidas -= 1/2
                if vidas <= 0:
                    print('Se te acabaron las vidas')
                    gano = False
                    break
        else:
            if pistas != 0:
                if pistas != pista_usada:
                    print(f'PISTA: {clue}')
                    pistas = pista_usada
                else:
                    print('No hay más pistas aca')
            else:
                print('No te quedan pistas')

    return vidas, pistas, gano
