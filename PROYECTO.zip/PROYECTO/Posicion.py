import numpy as np
import random
#sopa de letras
#clase para las posiciones

#clase para la posicion
class Position:
    def __init__(self, fila, columna):
        self.fila = fila
        self.columna = columna
        #posiciones de donde termina la posicion de la palabra por x, y
        self.endX = [-1, 0, 1][random.randint(0,2)]
        self.endY = [-1, 0, 1][random.randint(0,2)]
        if self.endX == 0 and self.endY == 0:
            self.endX = 1

    def next(self, pasos=1):
        self.fila += pasos * self.endX
        self.columna += pasos * self.endY

    #si la posicion de la palabra entra en el espacio
    def valid(self, dimension):
        return 0 <= self.fila < dimension and 0 <= self.columna < dimension

    def __str__(self):
        return f"[{self.fila}, {self.columna}]"

#clase para la tabla de palabras, donde se colocan las palabras con su posicion
class Tabla:
    def __init__(self, dimension):
        self.dimension = dimension
        #crear el array y reordenarlo para cada posicion
        self.matriz = np.array([' '] * dimension * dimension).reshape((dimension, dimension))
        #espacios lires
        self.free = dimension * dimension
        #lista de palabras
        self.words = []

    def __getitem__(self, position):
        if position.valid(self.dimension):
            return self.matriz[position.fila][position.columna]
        else:
            return ' '
    #colocar la posicion
    def __setitem__(self, position, value):
        #si la posicion entra en las dimendiones nxn 
        if position.valid(self.dimension):
            if self.matriz[position.fila][position.columna] == ' ':
                #se restas los espacios libres a medida que se agregan las palabras
                self.free -= 1
            self.matriz[position.fila][position.columna] = value

    #funcion para agregar la palabra 
    def put(self, word):
        #coordenadas random
        x, y = random.randint(0, self.dimension - 1), random.randint(0, self.dimension - 1)
        #se asigna la posicion de la palabra por sus cordenadas x,y 
        position = Position(x,y)
        #largo de cada palabra
        largo = len(word)
        position.next(largo)
        #si la posicion no es la valida en las dimensiones
        if not position.valid(self.dimension):
            return False
        position.next(-largo)

        #Cantidad de letras de la palabra que faltan por poner, se van restando hasta que se pone la palabra completa
        restantes = largo 
        for indice in range(largo):
            if self[position] == ' ' or self[position] == word[indice]:
                self[position] = word[indice]
                restantes -= 1
            position.next()

        #cuando ya la palabra se coloco completa
        if restantes == 0:
            self.words.append((x, y, word))

        return True

    def __str__(self):
        regla = f" {(' ' * int (self.dimension // 15 + 1))[:self.dimension * 2]}\n"
        linea = regla
        for i in range(self.dimension):
            #2 dimensiones, x, y
            linea += f"{i:2d} {' '.join(self.matriz[i].tolist())}\n"
        return linea + regla