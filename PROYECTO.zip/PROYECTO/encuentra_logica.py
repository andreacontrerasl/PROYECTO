import random
import emoji

def pick_option(options_list):
    random_option = random.choice(options_list)
    return random_option


def encuentra_logica_main(gano):
    options_list = ["🧡+🧡+🧡=45 \n 🍌+🍌+🧡=23 \n 🍌+⏰+⏰=10 \n ⏰+🍌+🍌x🧡=?\n", "🐧+🐧+🐧=27 \n🐧+🐝+🐝=19 \n🐝+🐦+🐦=13 \n🐝x🐧-🐦=?\n"]
    logic = pick_option(options_list)
    if logic == options_list[0]:
        answer = 67
    else:
        answer = 41
    print('''
----ENCUENTRA LA LÓGICA----
Debes descifrar la última operación guiandote de las primeras
Buena Suerte!''')
    while True:
        print(logic)
        adivinar_num = input('\nIngresa el resultado: ')
        while not (adivinar_num.isnumeric()):
            adivinar_num = input('\nIngresa el resultado, en números: ')
        adivinar_num = int(adivinar_num)
        if adivinar_num == answer:
            print('Felicidades, respuesta correcta!')
            gano = True
            break
        else:
            print('Respuesta incorrecta, vuelve a intentarlo')

    return gano


