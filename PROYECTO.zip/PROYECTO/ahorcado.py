import random
#from rooms import *

#funcion para que el usuario ingrese la letra
def pick_letter(letters):
  letter = (input('Ingrese la letra: ')).upper()
  #chequear que se solo 1 caracter ingresado
  while len(letter) != 1:
    letter = (input('Ingrese una sola la letra: ')).upper()
  #chequear que no lo hayan ingresado antes
  while letter in letters:
    letter = (input('Ya ingresaste esa letra, ingresa una letra nueva: ')).upper()
  #chequear que sea una letra
  while letter not in 'ABCDEFGHIJKLMNÑOPQRSTUVWXYZ':
    letter = (input('Debe ingresar una letra: ')).upper()
  return letter
    
#funcion que imprime el tablero del muñeco
def tablero_juego(dibujos, wrong_letter, correct_letter, word):
  #Imprimir el dibujo dependiendo de cuantos errores tenga (por la posicion de la lista dibujos)
  print(dibujos[len(wrong_letter)])
  end = " "
  #imprimir los espacios segun la cantidad de letras de la palabra
  space = '_'*len(word)
  for l in range(len(word)):
    if word[l] in correct_letter:
      space = space[:l] + word[l] + space[l+1:]
  
  for letter in space:
    print(letter, end)

#funcion para escoger una palabra aleatoriamente
def search_word(words_list):
  random_word = random.choice(words_list)
  return random_word

def ahorcado_main(vidas, pistas, gano):
  pistas_completas = pistas
  pistas2 = pistas - 1
  pistas3 = pistas2 - 1
  #dibujos dependiendo de los errores
  dibujos = ['''
      +---+
      |   |
          |
          |
          |
          |
    --------''', '''
      +---+
      |   |
      O   |
          |
          |
          |
    --------''', '''
      +---+
      |   |
      O   |
      |   |
          |
          |
    --------''', '''
      +---+
      |   |
      O   |
     /|   |
          |
          |
    --------''', '''
      +---+
      |   |
      O   |
     /|\  |
          |
          |
    --------''', '''
      +---+
      |   |
      O   |
     /|\  |
     /    |
          |
    --------''', '''
      +---+
      |   |
      O   |
     /|\  |
     / \  |
          |
    --------''']

  #Variables
  words_list = ['Metromix', 'Piscina', 'Rectorado']
  wrong_letter = ""
  correct_letter = ""
  question = ''
  clue_1 = ''
  clue_2 = ''
  clue_3 = ''
  word = search_word(words_list)
  word = word.upper()
  end_game = False

  #Las palabras y sus pistas
  if word == 'METROMIX':
    question = 'Me encuentro en la entrada de la Universidad'
    clue_1 = 'Sitio de comida'
    clue_2 = 'Al lado de las copias'
    clue_3 = 'Comienza por Metro'

  elif word == 'PISCINA':
    question = 'Me buscan y nunca me encuentran en la Universidad'
    clue_1 = 'Es rectangular'
    clue_2 = 'Tiene agua'
    clue_3 = 'Se puede nadar'

  elif word == 'RECTORADO':
    question = 'Tienes que subir muchos pisos para llegar a mi'
    clue_1 = 'Esta en el Eugenio Mendoza'
    clue_2 = 'Ultimo piso del Eugenio'
    clue_3 = 'Oficina del Rector'

  #while loop para jugar 
  print('---BIENVENIDO AL AHORCADO---\nDeber adivinar la palabra ingresando letra por letra')
  while end_game == False:
    print()
    print(question)
    print()
    tablero_juego(dibujos, wrong_letter, correct_letter, word)
    resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
    print()
    while not (resp_clue.isnumeric()) or int(resp_clue) not in range(1,3):
      resp_clue = input('\nDesea dar una respuesta [1] o ver una pista[2]: ')
    if resp_clue == '1':

      letter = pick_letter(correct_letter + wrong_letter)
      if letter in word:
        #si la letra esta en la palabra se agrega a la variable que guarda las letras acertadas
        correct_letter = correct_letter + letter

        #si es true es porque se adivino la palabra
        correct_letters = True

        #chequear si las letras ingresadas coinciden con la palabra
        for i in range(len(word)):
          if word[i] not in correct_letter:
            correct_letters = False

        if correct_letters:
          print(f'Felicidades, has ganado un cable HDMI, la palabra es {word}')
          gano = True
          end_game = True

      else:
        #si la letra no esta en la palara se agrega en la variable que guarda las letras incorrectas
        wrong_letter = wrong_letter + letter
        vidas -= 1/4
        if vidas <= 0:
          print('Se te acabaron las vidas, perdiste')
          gano = False
          end_game = True
          
        #Si ya se imprimieron todos los dibujos (Se ahorco al muñeco) se acaba el juego
        if len(wrong_letter) == len(dibujos) - 1:
          tablero_juego(dibujos, wrong_letter, correct_letter, word)
          print(f'Buuu! ya no tienes más intentos, perdiste, la palabra era {word}')
          gano = False
          end_game = True
          
    
    else:
      if pistas != 0:
        if pistas == pistas_completas:
          print(f'PISTA: {clue_1}')
          pistas -= 1
        elif pistas == pistas2:
          print(f'PISTA: {clue_2}')
          pistas -= 1
        elif pistas == pistas3:
          print(f'PISTA: {clue_3}')
          pistas -= 1
      else:
        print('No te quedan más pistas')

  return vidas, pistas, gano

