import random

def pick_question(questions_list):
    random_question = random.choice(questions_list)
    return random_question

def logica_booleana_main(vidas, gano):
    questions_list = ["¿Cuál es el valor de out de la siguiente lógica? \na, b = False, True, out = (a and b and not a) or (not b) or (b and a) or (a and not a and not b) ", "¿Cuál es el valor de out de la siguiente lógica?\na, b = False, True, out = (a and b and a) or (b) or (b or a) or (a and not a and not b)"]
    question = pick_question(questions_list)
    if question == questions_list[0]:
        answer = 'False'
    else:
        answer = 'True'
    print('''
-----LÓGICA BOOLEANA-----
Debe resolver el output de la siguente función lógica
Buena Suerte!''')
    while True:
        print('\n')
        print(question)
        respuesta = (input('\nIngrese el output: ')).title()
        if respuesta == answer:
            print('Felicidades, respuesta correcta')
            gano = True
            break
        else:
            print('Respuesta incorrecta, vuelve a intentarlo y recuerda que estas perdiendo vidas')
            vidas -= 1/2
            if vidas <= 0:
                print('Te quedaste sin vidas')
                gano = False
                break
    return vidas, gano
