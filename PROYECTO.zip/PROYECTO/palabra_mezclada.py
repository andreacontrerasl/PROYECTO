import random

def pick_words(words_list):
    random_words = random.choice(words_list)
    return random_words

def palabra_mezclada_main(vidas, gano):
    words_list = [["sarten", "paleta", "olla", "vaso", "hornilla"], ["poceta", "cepillo", "afeitadora", "regadera", "grifo"], ["zumba", "salsa", "flamengo", "tango", "perreo"]]
    words = pick_words(words_list)
    mezclar = [''.join(random.sample(word, len(word))) for word in words]
    if words == words_list[0]:
        category = 'Cocina'
    elif words == words_list[1]:
        category = 'Baño'
    else:
        category = 'Baile'
    palabras = 5
    print('''
----PALABRAS MEZCLADAS----
Debes de reordenar las letras para formar las palabras correctas
Buena Suerte!!''')
    while True:
        print('\n')
        print(mezclar)
        print(f'Las palabras están dentro de la categoría {category}\n')
        adivinar = (input('Ingrese la palabra: ')).lower()
        if adivinar in words:
            print(f'Bien, {adivinar} es una de las palabras')
            palabras -= 1
            if palabras == 0:
                print(f'\nFelicidades has adivinado toda la lista de palabras {words}')
                gano = True
                break
        elif adivinar not in words:
            print('Palabra incorrecta, sigue intentando')
            vidas -= 1/2
            if vidas <= 0:
                print('Se te acabaron las vidas')
                gano = False
                break

    return vidas, gano
